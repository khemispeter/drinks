# Luo Drinks — Backend

A small API + database that stores every submission from the "Contact & Order"
form on the Luo Drinks website: customer name, phone number, location in Gulu,
and the juice they described.

Data is stored in a real SQLite database file (`data/luo-drinks.db`) — nothing
gets lost when the form is submitted, and you can view every request from a
simple admin dashboard in your browser.

## What's inside

```
luo-drinks-backend/
├── server.js          the API server
├── admin/index.html   dashboard to view & manage orders
├── package.json
├── .env.example       copy this to .env and fill in your own values
└── data/              the SQLite database file lives here once you run it
```

## 1. Run it locally

You need [Node.js](https://nodejs.org) version 18 or newer installed.

```bash
cd luo-drinks-backend
npm install
cp .env.example .env
```

Open `.env` and set `ADMIN_KEY` to a long, made-up secret (this is the
password you'll use to view stored orders). Then start the server:

```bash
npm start
```

You should see:

```
Luo Drinks backend running on http://localhost:3000
Admin dashboard:            http://localhost:3000/admin
```

Open `http://localhost:3000/admin` in your browser, enter the admin key you
set, and click "View orders". It'll be empty until someone submits the form.

## 2. Connect it to your website

The website (`index.html`) currently saves form submissions only in the
visitor's own browser. To make it send data to this backend instead:

1. Deploy this backend somewhere (see step 3 below) and note its live URL,
   e.g. `https://luo-drinks-api.onrender.com`.
2. Open your website's `index.html`, find this line near the top of the
   `<script>` section:
   ```js
   const API_BASE = ''; // e.g. 'https://luo-drinks-api.onrender.com'
   ```
3. Set it to your backend's URL (no trailing slash), save, and re-upload
   `index.html` to your host.

That's it — the contact form will now POST straight to your database.

## 3. Deploy the backend (free options)

Any Node.js host works. **Render** is a simple free option:

1. Push this `luo-drinks-backend` folder to a GitHub repository.
2. Go to [render.com](https://render.com) → New → Web Service → connect the repo.
3. Settings:
   - **Build command:** `npm install`
   - **Start command:** `npm start`
4. Under "Environment", add the same variables from your `.env` file:
   - `ADMIN_KEY` → your secret
   - `ALLOWED_ORIGINS` → your website's URL, e.g. `https://luodrinks.netlify.app`
     (use `*` temporarily while testing, but lock it down before going live)
5. Deploy. Render gives you a URL like `https://luo-drinks-api.onrender.com`.

Railway and Fly.io work the same way if you prefer those instead.

⚠️ One thing to know about free tiers like Render's: the SQLite database file
is stored on the server's local disk. On most free plans that disk is
**not permanent** — if the service restarts or redeploys, the database can be
wiped. For a small juice stand testing things out that's often fine, but once
real customer orders matter, add a small persistent disk (Render calls this a
"Disk" add-on, a few dollars a month) or move to a hosted database like
Postgres. Ask me if you'd like help switching to Postgres later — the API
code barely changes.

## API reference

| Method | Endpoint                        | Auth        | Purpose                          |
|--------|----------------------------------|-------------|-----------------------------------|
| POST   | `/api/orders`                    | none        | Submit a new order (used by the website form) |
| GET    | `/api/orders`                    | admin key   | List all stored orders            |
| PATCH  | `/api/orders/:id/status`         | admin key   | Update an order's status          |
| DELETE | `/api/orders/:id`                | admin key   | Delete an order                   |
| GET    | `/api/security-events`           | admin key   | List logged admin-key attempts (with all captured fields) |
| GET    | `/api/security-events/summary`   | admin key   | Aggregated counts for the dashboard's charts |
| DELETE | `/api/security-events`           | admin key   | Clear the security event log      |
| GET    | `/api/health`                    | none        | Simple check that the server is up|

Admin-only endpoints require a header: `x-admin-key: <your ADMIN_KEY>`.

## Basic protections already built in

- Rejects a submission if name, phone, location, or details are missing
- Limits each visitor to 8 submissions per 10 minutes (basic spam guard)
- Admin endpoints are locked behind your private `ADMIN_KEY`
- CORS restricted to the site(s) you list in `ALLOWED_ORIGINS`
- Every failed or suspicious admin-key attempt is logged for review (see below)

This covers a small business site well. If Luo Drinks grows and you want
stronger protections (e.g. CAPTCHA, email notifications on new orders,
multiple staff logins), those can be added on top of this same foundation.

## Security event log

Every time someone submits the wrong admin key — or something that looks like
a SQL-injection attempt or a known scanner tool — to `/admin` or the API
directly, it's recorded in a `security_events` table and shown under the
**Security Log** tab of the admin dashboard. Each entry includes:

**Original fields**
- Timestamp and IP address (always normalized to plain **IPv4** dotted-decimal
  when the connection actually is IPv4 — see "IP address format" below)
- A best-guess OS and browser, parsed from the request's User-Agent header
- Which endpoint was hit and what value was typed into the admin key field
- A severity flag (`medium` for a plain wrong key, `high` for a SQL-injection-style
  payload, a known scanner tool, or a lockout)
- Basic client environment hints when available (timezone, screen size, language)

**Additional captured fields**
- **Geo-IP / geographical info** — country, region, city, latitude/longitude,
  and the timezone associated with the IP (from a Geo-IP lookup, distinct
  from the browser-reported timezone above)
- **ASN / ISP information** — the network operator/ISP and autonomous system
  number the IP belongs to (e.g. `AS15169 Google LLC`)
- **Fingerprint hash** — a SHA-256 hash combining several device/browser
  signals (canvas rendering, WebGL renderer, screen, fonts-adjacent metrics,
  timezone, etc.), so repeat attempts can be correlated even if the attacker's
  IP changes between attempts
- **Hardware concurrency / memory** — the browser-reported CPU core count
  (`navigator.hardwareConcurrency`) and approximate device RAM in GB
  (`navigator.deviceMemory`); the latter is only reported by Chromium-based
  browsers (Chrome, Edge, Opera) — Firefox and Safari don't expose it, so it
  will show as blank there
- **Behavioral / application-layer signal** — a JSON bundle combining:
  automated-tool detection from the User-Agent (curl, python-requests,
  sqlmap, Nikto, Nmap, Masscan, Postman, headless browsers, etc.), how many
  failed attempts this IP has made in the current 15-minute window, which
  ordinary browser headers (Accept / Accept-Language / Accept-Encoding) were
  missing, whether `navigator.webdriver` was set, whether any mouse/keyboard/
  touch activity was detected before the request, whether a hidden honeypot
  field was filled in, and how many milliseconds elapsed between page load
  and the request
- **HTTP response status** — the status code actually returned for that
  attempt (`401` for a wrong key or SQLi pattern, `429` for a lockout)

Click **"Details"** on any row in the Security Log table to expand these
extra fields for that entry.

After **6 failed attempts from the same IP within 15 minutes**, that IP is
temporarily locked out (HTTP 429) regardless of what it sends next, and the
lockout itself is logged too.

### Summary tab (bar / pie charts)

The **📊 Summary** tab visualizes everything above: attempts by reason
(bar), severity breakdown (pie), top attacking countries (bar), OS and
browser breakdown (pies), HTTP response status (bar), top ASN/ISP (bar), and
attempts over time (line). It's powered by a new `GET
/api/security-events/summary` admin endpoint that returns the aggregated
counts, and renders them with [Chart.js](https://www.chartjs.org/) (loaded
from a CDN only when you open that tab).

### IP address format

Node's HTTP server listens on both IPv4 and IPv6 by default, so an ordinary
IPv4 visitor is often reported internally as an "IPv4-mapped IPv6" address
like `::ffff:203.0.113.7`, and a local request as `::1`. The backend now
normalizes these back to plain IPv4 (`203.0.113.7`, `127.0.0.1`) wherever an
IP is captured or stored — in both the `orders` and `security_events`
tables — so what you see in the dashboard is a normal-looking IPv4 address
whenever the underlying connection actually is IPv4. A genuine IPv6-only
visitor (a real IPv6 address that isn't just an IPv4 address in disguise)
has no lossless IPv4 equivalent and is left as its real IPv6 address.

### Geo-IP / ASN lookup notes

- Uses [ip-api.com](https://ip-api.com)'s free JSON endpoint by default (no
  signup, 45 requests/minute, **free for non-commercial use only** — if
  Luo Drinks' use of this counts as commercial, get a key or switch
  providers via `GEO_API_BASE`/their paid plan).
- Results are cached in memory per IP for 6 hours and rate-limited to 40
  calls/minute internally, so a burst of attempts from the same IP only
  triggers one real lookup.
- Private/local IPs (`127.0.0.1`, `192.168.x.x`, etc.) are never sent to the
  external API — they're labeled "Private/Local network" instead.
- If the lookup fails, times out (2.5s), or the free-tier rate limit is hit,
  the event is still logged — just with the geo/ASN/ISP fields left blank.
  This never blocks or delays the actual 401/429 response by more than that
  timeout.

### Four honest limits worth knowing

1. **This app was never vulnerable to SQL injection in the first place.** Every
   database query in `server.js` uses parameterized statements (`db.prepare(...)`
   with named placeholders), so untrusted input is never concatenated into SQL.
   The detection above is pattern-matching on *what someone typed*, purely so
   you can see who's probing your site — it isn't patching a real hole.
2. **A website cannot read a visitor's browsing history.** Browsers deliberately
   block that for everyone's privacy, and there's no legitimate way around it.
   What's captured instead — IP, User-Agent, screen size, timezone, language —
   is the same kind of information any web server normally sees, and it's
   enough to profile repeat or automated attackers without doing anything invasive.
3. **Geo-IP, ASN, fingerprinting, and the behavioral signal are all
   spoofable or approximate.** Geo-IP maps an IP to a network's registered
   location, which for VPNs, mobile carriers, and corporate networks can be
   far from the person's actual location. The fingerprint hash and hardware/
   behavioral hints all come from the client's own browser — a script
   talking to the API directly (rather than through the dashboard's JS)
   simply won't send them at all, which is itself logged as a signal, but a
   sophisticated attacker could fake any of these values.
4. **The honeypot field and mouse-activity check only catch unsophisticated
   automation.** They're useful signals for correlation, not proof — a bot
   built to specifically target this login form could fill in neither trap.

Since the OS/browser guess comes from the User-Agent header, a determined
attacker can fake it — treat all of the above as helpful hints for spotting
patterns (e.g. "12 attempts from the same IP and ASN, no user-agent sent,
no mouse activity — likely a script"), not as courtroom-grade proof of who
someone is.
