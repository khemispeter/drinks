// Luo Drinks — backend API
// Stores contact/order form submissions in a local SQLite database file.
// Also runs a small intrusion-detection / attack-correlation log for the
// admin panel: every wrong admin key or SQL-injection-style probe is
// recorded with network, device, geo, and behavioral signals for review.
//
// Run locally:   npm install   then   npm start
// See README.md for deployment instructions (Render, Railway, Fly.io, etc.)

require('dotenv').config();
const path = require('path'); //Loads Node.js's built-in path module. It is normally used to safely construct file and folder paths
const express = require('express'); //Loads Express, which is used to create your web server and API routes.
const cors = require('cors'); //Loads the CORS middleware, which controls which websites/applications are allowed to make requests to your backend.
const Database = require('better-sqlite3'); //Loads better-sqlite3, which allows your application to communicate with a SQLite database.

const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || '';
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '*')
  .split(',') // split origin at commas,
  .map(s => s.trim()) //removes unneccesary space
  .filter(Boolean); //removes empty entries

// Base URL for the free IP-geolocation/ASN lookup used in the security log.
// Default is ip-api.com's free JSON endpoint (45 req/min, free for non-commercial
// use, no signup). Swap in a different provider here if you outgrow it.
const GEO_API_BASE = process.env.GEO_API_BASE || 'http://ip-api.com/json';

if (!ADMIN_KEY) {
  console.warn(
    '\n⚠️  ADMIN_KEY is not set in your .env file.\n' +
    '   Anyone will be blocked from viewing stored orders until you set one.\n'
  );
}

// ---------- Database setup ----------
const DB_PATH = path.join(__dirname, 'data', 'luo-drinks.db');
require('fs').mkdirSync(path.join(__dirname, 'data'), { recursive: true });//ceate folder data if not there.

const db = new Database(DB_PATH); // open database at this location path
db.pragma('journal_mode = WAL');

//WAL means Write-Ahead Logging.

//SQLite's WAL mode generally improves concurrency because readers can continue accessing the database while changes are being written.

//For a small ordering application, this is a reasonable configuration.

db.exec(`
  CREATE TABLE IF NOT EXISTS orders (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    phone         TEXT NOT NULL,
    location      TEXT NOT NULL,
    details       TEXT NOT NULL,
    status        TEXT NOT NULL DEFAULT 'new',
    submitted_at  TEXT NOT NULL,
    ip_address    TEXT
  );
`);
// @name paramitaried is much safer than constructing SQL by concatenating user input, for example:
//protect application from sql injections
//avoid `INSERT INTO orders ... VALUES ('${name}', '${phone}', ...)`
const insertOrder = db.prepare(`
  INSERT INTO orders (name, phone, location, details, submitted_at, ip_address)
  VALUES (@name, @phone, @location, @details, @submitted_at, @ip_address)
`);

const listOrders = db.prepare(`SELECT * FROM orders ORDER BY id DESC`);
const getOrder = db.prepare(`SELECT * FROM orders WHERE id = ?`);
const updateStatus = db.prepare(`UPDATE orders SET status = ? WHERE id = ?`);
const deleteOrder = db.prepare(`DELETE FROM orders WHERE id = ?`);

// Security event log — records suspicious or failed admin-key attempts for review.
// Base columns (kept for older installs) plus the newer capture fields below.
db.exec(`
  CREATE TABLE IF NOT EXISTS security_events (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    occurred_at           TEXT NOT NULL,
    ip_address            TEXT,
    user_agent            TEXT,
    browser               TEXT,
    os                    TEXT,
    endpoint              TEXT,
    method                TEXT,
    reason                TEXT NOT NULL,
    severity              TEXT NOT NULL DEFAULT 'medium',
    attempted_value       TEXT,
    client_timezone       TEXT,
    client_screen         TEXT,
    client_language       TEXT,
    client_platform       TEXT,
    geo_country           TEXT,
    geo_region            TEXT,
    geo_city              TEXT,
    geo_lat               REAL,
    geo_lon               REAL,
    geo_timezone          TEXT,
    asn                   TEXT,
    isp                   TEXT,
    client_fingerprint    TEXT,
    client_hw_concurrency INTEGER,
    client_device_memory  REAL,
    behavior_signal       TEXT,
    http_status           INTEGER
  );
`);

// Migration path for databases created before these columns existed.
// Each ALTER is wrapped so "duplicate column" errors from an already-migrated
// (or freshly created) table are silently ignored.
const SECURITY_EVENT_MIGRATIONS = [
  `ALTER TABLE security_events ADD COLUMN geo_country TEXT`,
  `ALTER TABLE security_events ADD COLUMN geo_region TEXT`,
  `ALTER TABLE security_events ADD COLUMN geo_city TEXT`, // db schemma upgrade. add missing column.
  `ALTER TABLE security_events ADD COLUMN geo_lat REAL`,
  `ALTER TABLE security_events ADD COLUMN geo_lon REAL`,
  `ALTER TABLE security_events ADD COLUMN geo_timezone TEXT`,
  `ALTER TABLE security_events ADD COLUMN asn TEXT`,
  `ALTER TABLE security_events ADD COLUMN isp TEXT`,
  `ALTER TABLE security_events ADD COLUMN client_fingerprint TEXT`,
  `ALTER TABLE security_events ADD COLUMN client_hw_concurrency INTEGER`,
  `ALTER TABLE security_events ADD COLUMN client_device_memory REAL`,
  `ALTER TABLE security_events ADD COLUMN behavior_signal TEXT`,
  `ALTER TABLE security_events ADD COLUMN http_status INTEGER`
];
for (const sql of SECURITY_EVENT_MIGRATIONS) {
  try { 
    db.exec(sql);

   } catch (err) {
     /* column already exists — fine */ }
}

const insertSecurityEvent = db.prepare(`
  INSERT INTO security_events
    (occurred_at, ip_address, user_agent, browser, os, endpoint, method, reason, severity,
     attempted_value, client_timezone, client_screen, client_language, client_platform,
     geo_country, geo_region, geo_city, geo_lat, geo_lon, geo_timezone, asn, isp,
     client_fingerprint, client_hw_concurrency, client_device_memory, behavior_signal, http_status)
  VALUES
    (@occurred_at, @ip_address, @user_agent, @browser, @os, @endpoint, @method, @reason, @severity,
     @attempted_value, @client_timezone, @client_screen, @client_language, @client_platform,
     @geo_country, @geo_region, @geo_city, @geo_lat, @geo_lon, @geo_timezone, @asn, @isp,
     @client_fingerprint, @client_hw_concurrency, @client_device_memory, @behavior_signal, @http_status)
`);

const listSecurityEvents = db.prepare(`SELECT * FROM security_events ORDER BY id DESC LIMIT 500`);
const clearSecurityEvents = db.prepare(`DELETE FROM security_events`);

// ---------- Summary aggregation (for the dashboard's bar/pie charts) ----------
const summaryTotal = db.prepare(`SELECT COUNT(*) AS total FROM security_events`);
const summaryByReason = db.prepare(`
  SELECT reason, COUNT(*) AS count FROM security_events GROUP BY reason ORDER BY count DESC
`);
const summaryBySeverity = db.prepare(`
  SELECT severity, COUNT(*) AS count FROM security_events GROUP BY severity ORDER BY count DESC
`);
const summaryByCountry = db.prepare(`
  SELECT COALESCE(NULLIF(geo_country,''), 'Unknown') AS country, COUNT(*) AS count
  FROM security_events GROUP BY country ORDER BY count DESC LIMIT 10
`);
const summaryByOs = db.prepare(`
  SELECT COALESCE(NULLIF(os,''), 'Unknown') AS os, COUNT(*) AS count
  FROM security_events GROUP BY os ORDER BY count DESC
`);
const summaryByBrowser = db.prepare(`
  SELECT COALESCE(NULLIF(browser,''), 'Unknown') AS browser, COUNT(*) AS count
  FROM security_events GROUP BY browser ORDER BY count DESC
`);
const summaryByHttpStatus = db.prepare(`
  SELECT COALESCE(http_status, 0) AS status, COUNT(*) AS count
  FROM security_events GROUP BY status ORDER BY count DESC
`);
const summaryByIsp = db.prepare(`
  SELECT COALESCE(NULLIF(isp,''), 'Unknown') AS isp, COUNT(*) AS count
  FROM security_events GROUP BY isp ORDER BY count DESC LIMIT 10
`);
const summaryByDay = db.prepare(`
  SELECT substr(occurred_at, 1, 10) AS day, COUNT(*) AS count
  FROM security_events GROUP BY day ORDER BY day ASC LIMIT 30
`);

// ---------- App setup ----------
const app = express();
app.use(express.json({ limit: '20kb' }));
// cross orgines resource sharing
app.use(cors({
  origin: (origin, callback) => {
    if (ALLOWED_ORIGINS.includes('*') || !origin || ALLOWED_ORIGINS.includes(origin)) {
      return callback(null, true);
    }
    return callback(new Error('Not allowed by CORS'));
  }
}));

// Node's HTTP server is dual-stack by default, so an ordinary IPv4 visitor
// often shows up as an "IPv4-mapped IPv6" address like "::ffff:203.0.113.7"
// (and localhost as "::1"). Normalize those back to plain IPv4 dotted-decimal
// so everything captured/stored/displayed is in IPv4 format when the
// underlying connection actually is IPv4. A genuine IPv6-only client (a real
// IPv6 address that isn't just an IPv4 address in disguise) has no lossless
// IPv4 equivalent and is left as-is.
function normalizeIp(ip) {
  if (!ip) return ip;
  ip = ip.trim();
  if (ip === '::1') return '127.0.0.1';

  // Dotted-decimal form: "::ffff:203.0.113.7"
  const dottedMapped = ip.match(/^::ffff:(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$/i);
  if (dottedMapped) return dottedMapped[1];

  // Hex-group form some proxies use: "::ffff:cb00:7107"
  const hexMapped = ip.match(/^::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/i);
  if (hexMapped) {
    const hi = parseInt(hexMapped[1], 16);
    const lo = parseInt(hexMapped[2], 16);
    return [(hi >> 8) & 0xff, hi & 0xff, (lo >> 8) & 0xff, lo & 0xff].join('.');
  }

  return ip;
}

function getClientIp(req) {
  const raw = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress || 'unknown';
  return normalizeIp(raw);
}

// naive in-memory rate limiter: max 8 submissions per IP per 10 minutes
const submissionLog = new Map();
function rateLimit(req, res, next) {
  const ip = getClientIp(req);
  const now = Date.now();
  const windowMs = 10 * 60 * 1000;
  const entries = (submissionLog.get(ip) || []).filter(t => now - t < windowMs);
  if (entries.length >= 8) {
    return res.status(429).json({ ok: false, error: 'Too many requests. Please try again later.' });
  }
  entries.push(now);
  submissionLog.set(ip, entries);
  req.clientIp = ip;
  next();
}

// ---------- Security event logging (admin-key abuse detection) ----------

// Very rough signatures for common SQL-injection-style payloads. This app never
// concatenates user input into SQL (every query uses parameterized statements,
// see above), so nothing here can actually run as SQL — this is purely to spot
// and record someone *trying* it, for review.
const SQLI_PATTERNS = [
  /(\-\-)|(\/\*)|(\*\/)|(;)/,
  /\bor\b\s+['"]?\d+['"]?\s*=\s*['"]?\d+['"]?/i,
  /\bunion\b[\s\S]*\bselect\b/i,
  /\bselect\b[\s\S]*\bfrom\b/i,
  /\bdrop\b\s+\btable\b/i,
  /\binsert\b\s+\binto\b/i,
  /\bupdate\b[\s\S]*\bset\b/i,
  /\bdelete\b\s+\bfrom\b/i,
  /\bsleep\s*\(\s*\d+\s*\)/i,
  /\bwaitfor\b\s+\bdelay\b/i,
  /xp_cmdshell/i,
  /information_schema/i,
  /['"]\s*or\s*['"]/i
];

function isSuspicious(value) {
  if (!value) return false;
  return SQLI_PATTERNS.some(re => re.test(value));
}

// Rough, spoofable-but-useful OS/browser guess from the User-Agent header.
function parseUserAgent(ua) {
  ua = ua || '';
  let os = 'Unknown';
  if (/windows nt 10|windows nt 11/i.test(ua)) os = 'Windows 10/11';
  else if (/windows nt/i.test(ua)) os = 'Windows (older)';
  else if (/mac os x/i.test(ua)) os = 'macOS';
  else if (/android/i.test(ua)) os = 'Android';
  else if (/iphone|ipad|ipod/i.test(ua)) os = 'iOS';
  else if (/linux/i.test(ua)) os = 'Linux';

  let browser = 'Unknown';
  if (!ua) browser = 'No user-agent sent (likely a script or bot)';
  else if (/edg\//i.test(ua)) browser = 'Edge';
  else if (/opr\//i.test(ua) || /opera/i.test(ua)) browser = 'Opera';
  else if (/chrome\//i.test(ua) && !/chromium/i.test(ua)) browser = 'Chrome';
  else if (/firefox\//i.test(ua)) browser = 'Firefox';
  else if (/safari\//i.test(ua) && !/chrome/i.test(ua)) browser = 'Safari';
  else browser = 'Other / command-line tool';

  return { os, browser };
}

// Known automation / scripting / scanner signatures found in the User-Agent
// header. This is an application-layer behavioral signal: a normal visitor's
// browser won't send these, so a match is a strong hint the request wasn't
// made by a human clicking around in a browser.
const AUTOMATION_UA_SIGNATURES = [
  [/sqlmap/i, 'sqlmap'],
  [/nikto/i, 'Nikto'],
  [/nmap/i, 'Nmap'],
  [/masscan/i, 'Masscan'],
  [/headlesschrome/i, 'Headless Chrome'],
  [/phantomjs/i, 'PhantomJS'],
  [/python-requests/i, 'python-requests'],
  [/scrapy/i, 'Scrapy'],
  [/\bcurl\//i, 'curl'],
  [/\bwget\//i, 'Wget'],
  [/postmanruntime/i, 'Postman'],
  [/go-http-client/i, 'Go http client'],
  [/\baxios\//i, 'axios'],
  [/node-fetch/i, 'node-fetch'],
  [/libwww-perl/i, 'Perl LWP'],
  [/okhttp/i, 'OkHttp'],
  [/^java\//i, 'Java client']
];

// Automation signatures unambiguous enough to escalate severity on their own,
// even when the admin-key value itself doesn't look like a SQLi payload.
const KNOWN_ATTACK_TOOLS = new Set(['sqlmap', 'Nikto', 'Nmap', 'Masscan']);

function detectAutomationTool(ua) {
  if (!ua) return 'No user-agent sent';
  for (const [re, label] of AUTOMATION_UA_SIGNATURES) {
    if (re.test(ua)) return label;
  }
  return null; // looks like an ordinary browser UA
}

// ---------- (a) Geo-IP / (c) ASN + ISP lookup ----------
// Best-effort, cached, rate-limited, and never allowed to block or crash a
// response — if the lookup fails or times out we just store nulls.
const GEO_LOOKUP_TIMEOUT_MS = 2500;
const GEO_CACHE_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours
const geoCache = new Map(); // ip -> { data, expiresAt }
const geoCallTimestamps = [];
const GEO_MAX_CALLS_PER_MIN = 40; // stay under ip-api.com's free 45/min limit

function isPrivateOrLocalIp(ip) {
  if (!ip || ip === 'unknown') return true;
  if (ip === '::1' || ip === '127.0.0.1') return true;
  if (/^(::ffff:)?10\./.test(ip)) return true;
  if (/^(::ffff:)?192\.168\./.test(ip)) return true;
  if (/^(::ffff:)?172\.(1[6-9]|2\d|3[01])\./.test(ip)) return true;
  if (/^fc00:|^fe80:/i.test(ip)) return true;
  return false;
}

function geoRateLimitOk() {
  const now = Date.now();
  while (geoCallTimestamps.length && now - geoCallTimestamps[0] > 60000) geoCallTimestamps.shift();
  if (geoCallTimestamps.length >= GEO_MAX_CALLS_PER_MIN) return false;
  geoCallTimestamps.push(now);
  return true;
}

const EMPTY_GEO = {
  geo_country: null, geo_region: null, geo_city: null,
  geo_lat: null, geo_lon: null, geo_timezone: null,
  asn: null, isp: null
};

async function lookupGeoIp(ip) {
  if (isPrivateOrLocalIp(ip)) {
    return { ...EMPTY_GEO, geo_country: 'Private/Local network' };
  }
  if (typeof fetch !== 'function') return EMPTY_GEO; // Node <18 without global fetch

  const cached = geoCache.get(ip);
  if (cached && cached.expiresAt > Date.now()) return cached.data;

  if (!geoRateLimitOk()) return EMPTY_GEO;

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), GEO_LOOKUP_TIMEOUT_MS);
    const url = `${GEO_API_BASE}/${encodeURIComponent(ip)}?fields=status,country,regionName,city,lat,lon,timezone,isp,as,query`;
    const response = await fetch(url, { signal: controller.signal });
    clearTimeout(timer);
    if (!response.ok) return EMPTY_GEO;
    const json = await response.json();
    if (json.status !== 'success') return EMPTY_GEO;

    const data = {
      geo_country: json.country || null,
      geo_region: json.regionName || null,
      geo_city: json.city || null,
      geo_lat: typeof json.lat === 'number' ? json.lat : null,
      geo_lon: typeof json.lon === 'number' ? json.lon : null,
      geo_timezone: json.timezone || null,
      asn: json.as || null,       // e.g. "AS15169 Google LLC"
      isp: json.isp || null
    };
    geoCache.set(ip, { data, expiresAt: Date.now() + GEO_CACHE_TTL_MS });
    return data;
  } catch (err) {
    return EMPTY_GEO; // timeout, network error, etc. — never let this break logging
  }
}

// ---------- (e) Behavioral / application-layer signal ----------
// Combines server-observable signals (missing browser headers, known
// automation UA, attack velocity from this IP) with optional client-supplied
// hints sent by the admin dashboard's JS (webdriver flag, mouse activity,
// honeypot field, time-to-submit). A script hitting the API directly will
// simply be missing the client hints, which is itself a useful signal.
function buildBehaviorSignal({ req, ua, ip }) {
  const attemptsInWindow = (failedAdminAttempts.get(ip) || []).length;
  const missingHeaders = [];
  if (!req.headers['accept']) missingHeaders.push('Accept');
  if (!req.headers['accept-language']) missingHeaders.push('Accept-Language');
  if (!req.headers['accept-encoding']) missingHeaders.push('Accept-Encoding');

  const timeToSubmitRaw = parseInt(req.headers['x-client-time-to-submit'], 10);

  return JSON.stringify({
    automation_tool: detectAutomationTool(ua),
    attempts_in_window: attemptsInWindow,
    missing_headers: missingHeaders,
    webdriver_detected: req.headers['x-client-webdriver'] === 'true',
    mouse_activity_detected: req.headers['x-client-mouse-activity'] === 'true',
    honeypot_triggered: !!clean(req.headers['x-client-honeypot'], 100),
    time_to_submit_ms: Number.isFinite(timeToSubmitRaw) ? timeToSubmitRaw : null
  });
}

async function logSecurityEvent({ req, providedKey, reason, severity, httpStatus }) {
  const ip = getClientIp(req);
  const ua = req.headers['user-agent'] || '';
  const { os, browser } = parseUserAgent(ua);
  const geo = await lookupGeoIp(ip);
  const behaviorSignal = buildBehaviorSignal({ req, ua, ip });

  const hwConcurrencyRaw = parseInt(req.headers['x-client-hw-concurrency'], 10);
  const deviceMemoryRaw = parseFloat(req.headers['x-client-device-memory']);

  insertSecurityEvent.run({
    occurred_at: new Date().toISOString(),
    ip_address: ip,
    user_agent: ua,
    browser,
    os,
    endpoint: req.originalUrl,
    method: req.method,
    reason,
    severity,
    attempted_value: providedKey ? clean(providedKey, 300) : null,
    client_timezone: clean(req.headers['x-client-timezone'], 60) || null,
    client_screen: clean(req.headers['x-client-screen'], 30) || null,
    client_language: clean(req.headers['x-client-language'], 30) || null,
    client_platform: clean(req.headers['x-client-platform'], 60) || null,
    geo_country: geo.geo_country,
    geo_region: geo.geo_region,
    geo_city: geo.geo_city,
    geo_lat: geo.geo_lat,
    geo_lon: geo.geo_lon,
    geo_timezone: geo.geo_timezone,
    asn: geo.asn,
    isp: geo.isp,
    client_fingerprint: clean(req.headers['x-client-fingerprint'], 128) || null,
    client_hw_concurrency: Number.isFinite(hwConcurrencyRaw) ? hwConcurrencyRaw : null,
    client_device_memory: Number.isFinite(deviceMemoryRaw) ? deviceMemoryRaw : null,
    behavior_signal: behaviorSignal,
    http_status: httpStatus
  });
  return ip;
}

// max 6 failed admin-key attempts per IP per 15 minutes, then a temporary lockout
const failedAdminAttempts = new Map();
function isLockedOut(ip) {
  const now = Date.now();
  const windowMs = 15 * 60 * 1000;
  const attempts = (failedAdminAttempts.get(ip) || []).filter(t => now - t < windowMs);
  failedAdminAttempts.set(ip, attempts);
  return attempts.length >= 6;
}
function recordFailedAttempt(ip) {
  const attempts = failedAdminAttempts.get(ip) || [];
  attempts.push(Date.now());
  failedAdminAttempts.set(ip, attempts);
}

async function requireAdmin(req, res, next) {
  const providedKey = req.headers['x-admin-key'] || req.query.key || '';
  const ip = getClientIp(req);
  const ua = req.headers['user-agent'] || '';

  if (isLockedOut(ip)) {
    await logSecurityEvent({ req, providedKey, reason: 'brute_force_lockout', severity: 'high', httpStatus: 429 });
    return res.status(429).json({ ok: false, error: 'Too many failed attempts. Try again later.' });
  }

  if (!ADMIN_KEY || providedKey !== ADMIN_KEY) {
    recordFailedAttempt(ip);
    const suspicious = isSuspicious(providedKey);
    const scannerTool = detectAutomationTool(ua);
    const isKnownAttackTool = KNOWN_ATTACK_TOOLS.has(scannerTool);

    let reason = suspicious ? 'sqli_pattern_detected' : 'invalid_admin_key';
    if (!suspicious && isKnownAttackTool) reason = 'scanner_tool_detected';
    const severity = (suspicious || isKnownAttackTool) ? 'high' : 'medium';

    await logSecurityEvent({ req, providedKey, reason, severity, httpStatus: 401 });
    return res.status(401).json({ ok: false, error: 'Unauthorized' });
  }

  failedAdminAttempts.delete(ip); // reset on a good login
  next();
}

function clean(str, maxLen) {
  return String(str || '').trim().slice(0, maxLen);
}

// ---------- Public API ----------

// Health check
app.get('/api/health', (req, res) => res.json({ ok: true }));

// Submit a new order from the contact form
app.post('/api/orders', rateLimit, (req, res) => {
  const name = clean(req.body.name, 100);
  const phone = clean(req.body.phone, 30);
  const location = clean(req.body.location, 150);
  const details = clean(req.body.details, 1000);

  const errors = [];
  if (!name) errors.push('name is required');
  if (!phone || phone.replace(/\D/g, '').length < 7) errors.push('a valid phone number is required');
  if (!location) errors.push('location is required');
  if (!details) errors.push('details is required');

  if (errors.length) {
    return res.status(400).json({ ok: false, error: errors.join(', ') });
  }

  const submitted_at = new Date().toISOString();
  const result = insertOrder.run({
    name, phone, location, details,
    submitted_at,
    ip_address: req.clientIp || null
  });

  res.status(201).json({ ok: true, id: result.lastInsertRowid, submitted_at });
});

// ---------- Admin API (requires x-admin-key header) ----------

// List all orders
app.get('/api/orders', requireAdmin, (req, res) => {
  res.json({ ok: true, orders: listOrders.all() });
});

// Update an order's status (e.g. new -> confirmed -> delivered)
app.patch('/api/orders/:id/status', requireAdmin, (req, res) => {
  const { status } = req.body;
  const allowed = ['new', 'confirmed', 'delivered', 'cancelled'];
  if (!allowed.includes(status)) {
    return res.status(400).json({ ok: false, error: `status must be one of: ${allowed.join(', ')}` });
  }
  const order = getOrder.get(req.params.id);
  if (!order) return res.status(404).json({ ok: false, error: 'Order not found' });
  updateStatus.run(status, req.params.id);
  res.json({ ok: true });
});

// Delete an order
app.delete('/api/orders/:id', requireAdmin, (req, res) => {
  const order = getOrder.get(req.params.id);
  if (!order) return res.status(404).json({ ok: false, error: 'Order not found' });
  deleteOrder.run(req.params.id);
  res.json({ ok: true });
});

// List logged security events (failed/suspicious admin-key attempts)
app.get('/api/security-events', requireAdmin, (req, res) => {
  res.json({ ok: true, events: listSecurityEvents.all() });
});

// Aggregated counts for the dashboard's bar/pie-chart summary
app.get('/api/security-events/summary', requireAdmin, (req, res) => {
  res.json({
    ok: true,
    total: summaryTotal.get().total,
    byReason: summaryByReason.all(),
    bySeverity: summaryBySeverity.all(),
    byCountry: summaryByCountry.all(),
    byOs: summaryByOs.all(),
    byBrowser: summaryByBrowser.all(),
    byHttpStatus: summaryByHttpStatus.all(),
    byIsp: summaryByIsp.all(),
    byDay: summaryByDay.all()
  });
});

// Clear the security event log
app.delete('/api/security-events', requireAdmin, (req, res) => {
  clearSecurityEvents.run();
  res.json({ ok: true });
});

// ---------- Simple admin dashboard (static HTML, key entered client-side) ----------
app.use('/admin', express.static(path.join(__dirname, 'admin')));

app.listen(PORT, () => {
  console.log(`Luo Drinks backend running on http://localhost:${PORT}`);
  console.log(`Admin dashboard:            http://localhost:${PORT}/admin`);
});
